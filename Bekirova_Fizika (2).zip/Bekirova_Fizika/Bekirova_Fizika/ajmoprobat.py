# Define the command functions

# Initialize a string variable to collect all commands
all_commands = ""

def append_command(command_text):
    global all_commands
    all_commands += command_text + '\n'
    # Print the command to simulate sending it to the fiscal machine
    print(f"Command prepared: {command_text}")

def execute_all_commands():
    """
    Writes all collected commands to the command.txt file.
    """
    file_path = "fiscal_machine_commands.txt"
    with open(file_path, 'w') as file:  # Open file in write mode to save all commands
        file.write(all_commands)
    print(f"All commands have been written to {file_path}")

def open_non_fiscal_receipt():
    append_command("38,1,______,_,__;")

def Open_Prices():
    append_command("300,1,______,_,__;0;0;Loading items.      Please wait...;C:\\Users\\MovieJay\\Desktop\\Bekirova_Fizika\\Cijene.txt;")

def print_non_fiscal_text(text):
    append_command(f"42,1,______,_,__;;{text};")

def close_non_fiscal_receipt():
    append_command("39,1,______,_,__;")

def open_fiscal_receipt(IOSA, operator, password, till_number, receipt_number=""):
    append_command(f"48,1,______,_,__;{IOSA};{operator};{password};{till_number};{receipt_number}")

def sell_item(PLU, quantity=1.000, percent=0):
    append_command(f"52,1,______,_,__;{PLU};{quantity};{percent};")

def subtotal():
    append_command("51,1,______,_,__;")

def payment(flag=";", amount=""):
    append_command("53,1,______,_,__;")
    
def close_fiscal_receipt():
    append_command("56,1,______,_,__;")

def program_item(PLU, price, name):
    append_command(f"107,1,______,_,__;2;2;{PLU};{price};{name};")

def void_receipt():
    append_command("301,1,______,_,__;")

def custom_command(product):
    append_command(f'305,1,______,_,__;"1234567";1.000;0;0.1;1;"{product}";')

def Finish_It():
    subtotal()
    payment()
    close_fiscal_receipt()
    execute_all_commands()

# Main function to test commands
def main():
    open_fiscal_receipt(1234567890123456,"1","0000","1")
    sell_item("00002", 1, 0)
    Finish_It()

if __name__ == "__main__":
    main()