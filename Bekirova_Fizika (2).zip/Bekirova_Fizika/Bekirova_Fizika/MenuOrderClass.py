import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QLabel, QGridLayout
from PyQt5.QtGui import QColor, QPalette, QLinearGradient
from PyQt5.QtCore import Qt, QSize

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Three Sections Example')

        # Set gradient background
        palette = QPalette()
        gradient = QLinearGradient(0, 0, 0, 400)
        gradient.setColorAt(0.0, QColor(255, 255, 255))  # Start color
        gradient.setColorAt(1.0, QColor(173, 216, 230))  # End color
        palette.setBrush(QPalette.Window, gradient)
        self.setPalette(palette)

        # Make the window fullscreen and remove the top bar
        self.setWindowFlag(Qt.FramelessWindowHint)
        self.showFullScreen()

        # Main widget container
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)

        # Create a layout for the close button
        top_layout = QHBoxLayout()
        top_layout.addStretch(1)
        close_button = QPushButton('Close')
        close_button.setStyleSheet("background-color: red; color: white; font-size: 18px;")
        close_button.setFixedSize(100, 50)
        close_button.clicked.connect(self.close)
        top_layout.addWidget(close_button)

        # Main horizontal layout for sections
        sections_layout = QHBoxLayout()

        # Create three sections (vertical layouts)
        section1_layout = QVBoxLayout()
        section2_layout = QVBoxLayout()
        section3_layout = QVBoxLayout()

        # Section label for Section 1
        section_label = QLabel('SECTIONS')
        section_label.setAlignment(Qt.AlignCenter)
        section_label.setStyleSheet('font-size: 24px;')  # Adjust font
        section1_layout.addWidget(section_label)

        # Add buttons to section 1 (smaller)
        for i in range(4):
            button = QPushButton(f'{i+1}')
            button.setMinimumSize(QSize(150, 70))  # Set minimum size for buttons
            section1_layout.addWidget(button)

        # Set alignment for section 1 layout
        section1_layout.setAlignment(Qt.AlignCenter)

        # Add buttons to section 2 (middle)
        self.grid_layout = QGridLayout()
        section2_layout.addLayout(self.grid_layout)

        self.updateItemSection()

        # Set alignment for section 2 layout
        section2_layout.setAlignment(Qt.AlignCenter | Qt.AlignBottom)

        # Add buttons to section 3 (smaller)
        for i in range(2):
            button = QPushButton(f'S3 Button {i+1}')
            button.setMinimumSize(QSize(150, 70))  # Set minimum size for buttons
            section3_layout.addWidget(button)

        # Set alignment for section 3 layout
        section3_layout.setAlignment(Qt.AlignCenter)

        # Add section layouts to sections_layout with proportional widths
        sections_layout.addLayout(section1_layout, 1)  # Width ratio 1 for section 1
        sections_layout.addLayout(section2_layout, 8)  # Width ratio 8 for section 2
        sections_layout.addLayout(section3_layout, 1)  # Width ratio 1 for section 3

        # Set spacing between sections
        sections_layout.setSpacing(20)  # Adjust spacing as needed

        # Add top_layout and sections_layout to main_layout
        main_layout.addLayout(top_layout)
        main_layout.addLayout(sections_layout)

        # Set central widget layout
        main_widget.setLayout(main_layout)

        # Connect resize event
        self.resizeEvent = self.onResize

        self.show()

    def updateItemSection(self):
        # Clear existing buttons
        for i in reversed(range(self.grid_layout.count())):
            item = self.grid_layout.itemAt(i)
            if item is not None:
                item.widget().deleteLater()

        # Add buttons to section 2 (middle)
        num_rows = 6  # Number of rows
        num_cols = 5  # Number of columns
        button_counter = 1
        division_factor = 1.3  # Adjust this factor as needed

        for row in range(num_rows):
            for col in range(num_cols):
                button = QPushButton(f'B{button_counter}')
                # Calculate size based on window size
                width = int(self.width() / (num_cols * division_factor))
                height = int(self.height() / (num_rows + 1))  # +1 to leave some space at the bottom
                button.setMinimumSize(QSize(width, height))
                self.grid_layout.addWidget(button, row, col)
                button_counter += 1

        # Set spacing between widgets in section 2 grid layout
        self.grid_layout.setSpacing(10)  # Adjust spacing as needed for your layout

    def onResize(self, event):
        self.updateItemSection()
        return QMainWindow.resizeEvent(self, event)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = MainWindow()
    sys.exit(app.exec_())
