import json
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

class LoginPage(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Restaurant Fiscal App')

        button_font = QFont('Arial', 16)
        title_font = QFont('Arial', 40, QFont.Bold)
        footer_font = QFont('Arial', 12, QFont.Bold)

        self.title_label = QLabel('Welcome', self)
        self.title_label.setFont(title_font)
        self.title_label.setStyleSheet('color: white; background: transparent;')
        self.title_label.setAlignment(Qt.AlignCenter | Qt.AlignTop)
        self.title_label.setFixedHeight(75)

        self.footer_label = QLabel('Made by Vexen Studio', self)
        self.footer_label.setFont(footer_font)
        self.footer_label.setStyleSheet('color: white; background: transparent;')
        self.footer_label.setAlignment(Qt.AlignRight | Qt.AlignBottom)

        self.cash_register_button = QPushButton('Cash Register', self)
        self.cash_register_button.setFont(button_font)
        self.cash_register_button.setFixedSize(250, 75)
        self.setupButtonStyle(self.cash_register_button)

        self.administration_button = QPushButton('Administration', self)
        self.administration_button.setFont(button_font)
        self.administration_button.setFixedSize(250, 75)
        self.setupButtonStyle(self.administration_button)

        self.option_button = QPushButton('Option', self)
        self.option_button.setFont(button_font)
        self.option_button.setFixedSize(250, 75)
        self.setupButtonStyle(self.option_button)

        self.exit_button = QPushButton('Exit', self)
        self.exit_button.setFont(button_font)
        self.exit_button.setFixedSize(250, 75)
        self.setupButtonStyle(self.exit_button)
        self.exit_button.clicked.connect(self.close)

        layout = QGridLayout()
        layout.addWidget(self.title_label, 0, 0, 1, 2)
        layout.addWidget(self.cash_register_button, 1, 0)
        layout.addWidget(self.administration_button, 1, 1)
        layout.addWidget(self.option_button, 2, 0)
        layout.addWidget(self.exit_button, 2, 1)
        layout.addWidget(self.footer_label, 3, 1)
        layout.setAlignment(Qt.AlignCenter)
        self.setLayout(layout)

        self.title_label.setGeometry(0, 10, 500, 75)
        self.setFixedSize(600, 400)
        self.center()
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setStyleSheet('background: black;')

        self.cash_register_button.clicked.connect(self.openCashRegister)
        self.option_button.clicked.connect(self.openOptions)
        self.administration_button.clicked.connect(self.openAdministration)

    def setupButtonStyle(self, button):
        button.setStyleSheet(
            """
            QPushButton {
                background-color: #333; 
                border-radius: 15px; 
                color: white; 
                border: 2px solid #555; 
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #444;
            }
            """
        )

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0.0, QColor(0, 0, 0))
        gradient.setColorAt(1.0, QColor(50, 50, 50))

        painter.setBrush(QBrush(gradient))
        painter.drawRect(self.rect())

    def center(self):
        screen = QApplication.primaryScreen().geometry()
        size = self.geometry()
        x = (screen.width() - size.width()) // 2
        y = (screen.height() - size.height()) // 2
        self.move(x, y)

    def openCashRegister(self):
        self.close()
        self.cash_register_window = CashRegisterWindow()
        self.cash_register_window.showFullScreen()

    def openOptions(self):
        self.close()
        self.options_window = OptionsWindow()
        self.options_window.showFullScreen()

    def openAdministration(self):
        self.close()
        self.options_window = Administration()
        self.options_window.showFullScreen()

class OptionsWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Options')

        # Set the font for the title
        title_font = QFont('Arial', 20, QFont.Bold)
        
        # Set the font for the labels
        label_font = QFont('Arial', 16)
        self.setStyleSheet('background: black; color: white;')
        # Create a title label
        self.title_label = QLabel('Options', self)
        self.title_label.setFont(title_font)
        self.title_label.setStyleSheet('color: black; background: transparent;')
        self.title_label.setAlignment(Qt.AlignCenter)

        # Create a combo box for language selection
        self.language_label = QLabel('Language', self)
        self.language_label.setFont(label_font)
        self.language_label.setStyleSheet('color: black; background: transparent;')
        
        self.language_combo_box = QComboBox(self)
        self.language_combo_box.addItem('Bosnian')
        self.language_combo_box.addItem('English')
        self.language_combo_box.setFont(label_font)
        self.language_combo_box.setStyleSheet('color: black; background-color: #333;')

        # Create a combo box for color selection
        self.color_label = QLabel('Color', self)
        self.color_label.setFont(label_font)
        self.color_label.setStyleSheet('color: black; background: transparent;')
        
        self.color_combo_box = QComboBox(self)
        self.color_combo_box.addItem('System Color')
        self.color_combo_box.addItem('Black')
        self.color_combo_box.addItem('White')
        self.color_combo_box.setFont(label_font)
        self.color_combo_box.setStyleSheet('color: black; background-color: #333;')

        # Create a contacts label
        self.contacts_label = QLabel('Contacts', self)
        self.contacts_label.setFont(label_font)
        self.contacts_label.setStyleSheet('color: black; background: transparent;')

        self.contacts_content = QLabel('Phone: +123456789\nEmail: contact@vexenstudio.com', self)
        self.contacts_content.setFont(label_font)
        self.contacts_content.setStyleSheet('color: black; background: transparent;')

        # Create a close button
        self.close_button = QPushButton('Close', self)
        self.close_button.setFont(label_font)
        self.close_button.setStyleSheet('background-color: red; color: black; border-radius: 10px;')
        self.close_button.clicked.connect(self.openLoginPage)  # Connect the close button to the openLoginPage method

        # Create a layout and add widgets
        layout = QVBoxLayout()
        layout.addWidget(self.title_label)
        layout.addSpacing(20)
        
        # Create a horizontal layout for language selection
        language_layout = QHBoxLayout()
        language_layout.addWidget(self.language_label)
        language_layout.addWidget(self.language_combo_box)
        layout.addLayout(language_layout)
        
        layout.addSpacing(20)
        
        # Create a horizontal layout for color selection
        color_layout = QHBoxLayout()
        color_layout.addWidget(self.color_label)
        color_layout.addWidget(self.color_combo_box)
        layout.addLayout(color_layout)
        
        layout.addSpacing(20)
        
        # Add contacts information
        layout.addWidget(self.contacts_label)
        layout.addWidget(self.contacts_content)
        
        layout.addSpacing(20)
        
        layout.addWidget(self.close_button, 0, Qt.AlignCenter)
        
        self.setLayout(layout)

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        gradient = QLinearGradient(0, self.height(), 0, 0)
        gradient.setColorAt(0.0, QColor(0, 0, 0))
        gradient.setColorAt(1.0, QColor(50, 50, 50))
        painter.fillRect(self.rect(), gradient)

    def openLoginPage(self):
        self.close()  # Close the OptionsWindow
        self.login_page = LoginPage()
        self.login_page.show()

class AddArticleDialog(QDialog):
    def __init__(self, sections, last_barcode):
        super().__init__()
        self.sections = sections
        self.last_barcode = last_barcode
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Name input
        self.name_input = QLineEdit(self)
        self.name_input.setPlaceholderText('Enter article name')

        # Barcode input (auto-incremented)
        self.barcode_input = QLineEdit(self) 
        self.barcode_input.setPlaceholderText('Barcode')
        self.barcode_input.setText(str(self.last_barcode))
        self.barcode_input.setReadOnly(True)  # Make the barcode input read-only

        # PDV input with dropdown
        self.pdv_input = QComboBox(self)
        self.pdv_input.addItems([str(i) + '%' for i in range(1, 101)])
        self.pdv_input.setCurrentIndex(16)  # Set the default to 17%

        # Section input
        self.section_input = QComboBox(self)
        self.section_input.addItems(self.sections)

        # Option to add a new section
        self.new_section_input = QLineEdit(self)
        self.new_section_input.setPlaceholderText('Or enter new section')

        self.price_input = QLineEdit(self)
        self.price_input.setPlaceholderText('Enter price')

        # Add inputs to layout
        layout.addWidget(QLabel('Article Name:'))
        layout.addWidget(self.name_input)
        layout.addWidget(QLabel('Barcode:'))
        layout.addWidget(self.barcode_input)
        layout.addWidget(QLabel('Price:'))
        layout.addWidget(self.price_input)  # Add price input to the dialog
        layout.addWidget(QLabel('PDV:'))
        layout.addWidget(self.pdv_input)
        layout.addWidget(QLabel('Section:'))
        layout.addWidget(self.section_input)
        layout.addWidget(QLabel('New Section (optional):'))
        layout.addWidget(self.new_section_input)

        # Dialog buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.setLayout(layout)
        self.setWindowTitle('Add New Article')

class Administration(QMainWindow):
    def __init__(self):
        super().__init__()
        self.file_path = 'articles.json'  # Path to the JSON file
        self.sections = ['Food', 'Drinks']
        self.articles = []  # List to store articles
        self.init_ui()
        self.load_articles()

    def init_ui(self):
        try:
            # Set gradient background
            gradient = QLinearGradient(0, 0, 0, 1)
            gradient.setCoordinateMode(QLinearGradient.ObjectBoundingMode)
            gradient.setColorAt(0.0, QColor(240, 240, 240))
            gradient.setColorAt(1.0, QColor(200, 200, 200))
            palette = QPalette()
            palette.setBrush(QPalette.Window, QBrush(gradient))
            self.setPalette(palette)

            # Central widget and layout
            central_widget = QWidget()
            main_layout = QHBoxLayout()

            # Left sidebar layout
            left_sidebar = QVBoxLayout()
            self.articles_button = QPushButton('Articles')
            self.clients_button = QPushButton('Clients')
            self.suppliers_button = QPushButton('Suppliers')

            # Adjust button sizes and styles
            button_size = 150  # Change this value to adjust the size
            self.articles_button.setFixedSize(button_size, button_size)
            self.clients_button.setFixedSize(button_size, button_size)
            self.suppliers_button.setFixedSize(button_size, button_size)

            button_style = """
                QPushButton {
                    border-radius: 20px;
                    background-color: #3d85c6;
                    color: white;
                    font-size: 16px;
                    padding: 10px;
                }
                QPushButton:hover {
                    background-color: #5588c6;
                }
            """
            self.articles_button.setStyleSheet(button_style)
            self.clients_button.setStyleSheet(button_style)
            self.suppliers_button.setStyleSheet(button_style)

            left_sidebar.addWidget(self.articles_button)
            left_sidebar.addWidget(self.clients_button)
            left_sidebar.addWidget(self.suppliers_button)
            left_sidebar.addStretch()  # Add a stretch to push the buttons to the top

            # Middle layout with table
            middle_layout = QVBoxLayout()
            self.table = QTableWidget()
            self.table.setRowCount(0)  # Start with no rows
            self.table.setColumnCount(5)
            self.table.setHorizontalHeaderLabels(['Name', 'Barcode', 'PDV', 'Section', 'Price', 'In Stock'])
            self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

            middle_layout.addWidget(self.table)

            # Right sidebar layout
            right_sidebar = QVBoxLayout()
            self.add_button = QPushButton('Add')
            self.remove_button = QPushButton('Remove')
            self.change_button = QPushButton('Change')

            # Adjust button sizes and styles
            sidebar_button_size = 150  # Change this value to adjust the size
            self.add_button.setFixedSize(sidebar_button_size, sidebar_button_size)
            self.remove_button.setFixedSize(sidebar_button_size, sidebar_button_size)
            self.change_button.setFixedSize(sidebar_button_size, sidebar_button_size)

            self.add_button.setStyleSheet(button_style)
            self.remove_button.setStyleSheet(button_style)
            self.change_button.setStyleSheet(button_style)

            # Connect the remove button to the remove_article method
            self.remove_button.clicked.connect(self.remove_article)
            self.add_button.clicked.connect(self.show_add_dialog)

            right_sidebar.addWidget(self.add_button)
            right_sidebar.addWidget(self.remove_button)
            right_sidebar.addWidget(self.change_button)
            right_sidebar.addStretch()  # Add a stretch to push the buttons to the top

            # Add Close button
            close_button = QPushButton('Close')
            close_button.setStyleSheet(button_style)
            close_button.clicked.connect(self.openLoginPage)  # Connect to the method that opens the login page

            # Bottom-right layout for the Close button
            bottom_right_layout = QVBoxLayout()
            bottom_right_layout.addStretch()  # Add a stretch to push the button to the bottom
            bottom_right_layout.addWidget(close_button)

            # Add all layouts to the main layout
            main_layout.addLayout(left_sidebar)
            main_layout.addLayout(middle_layout)
            main_layout.addLayout(right_sidebar)
            main_layout.addLayout(bottom_right_layout)  # Add the bottom-right layout

            # Set the central widget and main layout
            central_widget.setLayout(main_layout)
            self.setCentralWidget(central_widget)

            # Window settings
            self.setWindowTitle('Administration')
            self.show()
        except Exception as e:
            print(f"Error initializing UI: {e}")

    def show_add_dialog(self):
        last_barcode = self.get_next_barcode()
        dialog = AddArticleDialog(self.sections, last_barcode)
        if dialog.exec_() == QDialog.Accepted:
            # Process the input data here
            name = dialog.name_input.text()
            barcode = dialog.barcode_input.text()
            pdv = dialog.pdv_input.currentText()
            new_section = dialog.new_section_input.text()
            price = dialog.price_input.text()

            # Add the new section to the list if it exists
            if new_section and new_section not in self.sections:
                self.sections.append(new_section)

            section = new_section if new_section else dialog.section_input.currentText()

            # Ensure the name is unique within the section before adding the article
            if self.is_name_unique_in_section(name, section):
                # Ensure the barcode is unique before adding the article
                if self.is_barcode_unique(barcode):
                    self.add_article(name, barcode, pdv, section, price)
                    self.save_articles()  # Save the articles to JSON file
                else:
                    QMessageBox.warning(self, 'Duplicate Barcode', 'The barcode already exists. Please try again.')
            else:
                QMessageBox.warning(self, 'Duplicate Article Name', f'The article name "{name}" already exists in the "{section}" section. Please use a different name.')

    def is_name_unique_in_section(self, name, section):
        for row in range(self.table.rowCount()):
            existing_name = self.table.item(row, 0).text()
            existing_section = self.table.item(row, 3).text()
            if existing_name == name and existing_section == section:
                return False
        return True

    def get_next_barcode(self):
        existing_barcodes = [int(self.table.item(row, 1).text()) for row in range(self.table.rowCount())]
        new_barcode = max(existing_barcodes, default=0) + 1  # Start with the next number

        # Ensure the new barcode doesn't already exist
        while new_barcode in existing_barcodes:
            new_barcode += 1

        # Format the barcode to be 5 characters long
        return f"{new_barcode:05d}"

    def is_barcode_unique(self, barcode):
        for row in range(self.table.rowCount()):
            if self.table.item(row, 1).text() == barcode:
                return False
        return True

    def add_article(self, name, barcode, pdv, price, section):
        row_position = self.table.rowCount()
        self.table.insertRow(row_position)
        self.table.setItem(row_position, 0, QTableWidgetItem(name))
        self.table.setItem(row_position, 1, QTableWidgetItem(barcode))
        self.table.setItem(row_position, 2, QTableWidgetItem(pdv))
        self.table.setItem(row_position, 3, QTableWidgetItem(section))
        self.table.setItem(row_position, 4, QTableWidgetItem(price))
        self.table.setItem(row_position, 5, QTableWidgetItem('Yes'))  # Default value for 'In Stock'

        # Add the article to the internal list
        self.articles.append({
            'name': name,
            'barcode': barcode,
            'pdv': pdv,
            'section': section,
            'price': price,
            'in_stock': True
        })

    def save_articles(self):
        with open(self.file_path, 'w') as file:
            json.dump(self.articles, file, indent=4)

    def load_articles(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, 'r') as file:
                self.articles = json.load(file)
                self.table.setRowCount(0)  # Clear existing rows
                for article in self.articles:
                    row_position = self.table.rowCount()
                    self.table.insertRow(row_position)
                    self.table.setItem(row_position, 0, QTableWidgetItem(article['name']))
                    self.table.setItem(row_position, 1, QTableWidgetItem(article['barcode']))
                    self.table.setItem(row_position, 2, QTableWidgetItem(article['pdv']))
                    self.table.setItem(row_position, 3, QTableWidgetItem(article['section']))
                    self.table.setItem(row_position, 4, QTableWidgetItem(article['price']))
                    self.table.setItem(row_position, 5, QTableWidgetItem('Yes' if article['in_stock'] else 'No'))

    def remove_article(self):
        selected_row = self.table.currentRow()
        if selected_row >= 0:  # Check if a valid row is selected
            barcode = self.table.item(selected_row, 1).text()
            self.table.removeRow(selected_row)
            
            # Remove the article from the internal list
            self.articles = [article for article in self.articles if article['barcode'] != barcode]
            self.save_articles()  # Save the updated list to JSON file
        else:
            # Optional: Handle case when no row is selected (e.g., show a message)
            QMessageBox.warning(self, 'No Selection', 'Please select a row to remove.')

    def openLoginPage(self):
        self.close()  # Close the Administration window
        self.login_page = LoginPage()  # Replace with your actual login page class
        self.login_page.show()

class CashRegisterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.menu_order_window = None

        self.setWindowTitle('Cash Register')

        button_font = QFont('Arial', 16)
        footer_font = QFont('Arial', 12, QFont.Bold)

        self.close_button = QPushButton('Close', self)
        self.close_button.setFont(button_font)
        self.close_button.setFixedSize(100, 40)
        self.close_button.setStyleSheet('background-color: red; color: white; border-radius: 10px;')
        self.close_button.clicked.connect(self.openLoginPage)

        self.table_grid_layout = QGridLayout()
        self.table_grid_layout.setSpacing(30)

        for i in range(1, 31):
            table_button = QPushButton(f'Table {i}', self)
            table_button.setFont(button_font)
            table_button.setFixedSize(235, 150)
            table_button.setStyleSheet('background-color: #333; color: white; border-radius: 10px; border: 2px solid #555; padding: 10px;')
            table_button.setObjectName(f'table_{i}')
            table_button.clicked.connect(self.openMenuOrder)
            self.table_grid_layout.addWidget(table_button, (i-1)//6, (i-1)%6)

        self.footer_label = QLabel('<div style="text-align:right; color:white; margin:10px;">Made by Vexen Studio</div>', self)
        self.footer_label.setFont(footer_font)
        self.footer_label.setAlignment(Qt.AlignRight | Qt.AlignBottom)

        self.more_options_label = QLabel('More Options', self)
        self.more_options_label.setFont(button_font)
        self.more_options_label.setStyleSheet('color: white; background: #222; border-radius: 10px; padding: 5px; margin-bottom: 10px;')
        self.more_options_label.setAlignment(Qt.AlignTop | Qt.AlignCenter)

        self.more_options_grid_layout = QVBoxLayout()
        self.more_options_grid_layout.setSpacing(10)

        options = ["Deposit", "Unblocking Fiscal Machine", "Receipt Viewer", "Periodic Report", "Daily Report", "Turnover By Waiters", "Turnover by POS Terminal"]
        for idx, option in enumerate(options):
            option_button = QPushButton(option, self)
            option_button.setFont(button_font)
            option_button.setFixedSize(250, 100)
            option_button.setStyleSheet('background-color: #555; color: white; border-radius: 10px; border: 2px solid #777; padding: 10px;')
            option_button.setObjectName(f'option_{idx+1}')
            self.more_options_grid_layout.addWidget(option_button)

        more_options_widget = QWidget()
        more_options_widget.setLayout(self.more_options_grid_layout)

        main_layout = QGridLayout()
        main_layout.addWidget(self.close_button, 0, 0, Qt.AlignTop | Qt.AlignLeft)
        main_layout.addLayout(self.table_grid_layout, 1, 0)
        main_layout.addWidget(self.more_options_label, 0, 1, Qt.AlignTop)
        main_layout.addWidget(more_options_widget, 1, 1, Qt.AlignTop)
        main_layout.addWidget(self.footer_label, 2, 1, Qt.AlignBottom | Qt.AlignRight)
        main_layout.setColumnStretch(0, 3)
        main_layout.setColumnStretch(1, 1)
        self.setLayout(main_layout)

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        gradient = QLinearGradient(0, self.height(), 0, 0)
        gradient.setColorAt(0.0, QColor(0, 0, 0))
        gradient.setColorAt(1.0, QColor(50, 50, 50))

        painter.setBrush(QBrush(gradient))
        painter.drawRect(self.rect())

    def openLoginPage(self):
        self.close()
        self.login_page = LoginPage()
        self.login_page.show()

    def openMenuOrder(self):
        sender = self.sender()
        table_number = int(sender.text().split()[1])  # Extract table number
        self.menu_order_window = MenuOrder(table_number)
        self.menu_order_window.receiptNotEmpty.connect(self.handleReceiptNotEmpty)  # Connect the signal
        self.menu_order_window.show()

    def handleReceiptNotEmpty(self, table_number, booll):
        # Find the table button and change its color to red
        button = self.findChild(QPushButton, f'table_{table_number}')
        if booll == True:
            if button:
                button.setStyleSheet('background-color: red; color: white; border-radius: 10px; border: 2px solid #555; padding: 10px;')
            else: 
                print("No button has been found")
        elif booll == False:
            if button:
                button.setStyleSheet('background-color: #333; color: white; border-radius: 10px; border: 2px solid #555; padding: 10px;')
            else:
                print("No button has been found")
        
class MenuOrder(QWidget):

    receiptNotEmpty = pyqtSignal(int, bool)

    def __init__(self, table_number):
        super().__init__()
        self.table_number = table_number
        self.receipt_items = []  # Store items in the receipt
        self.initUI()
        self.loadData()
        self.loadReceiptData()  # Load existing receipt data if available

    def initUI(self):
        self.setWindowTitle('Menu Order')
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setStyleSheet('background: transparent;')

        self.showFullScreen()

        # Main layout
        main_layout = QVBoxLayout(self)

        # Container for close button and main content
        container_widget = QWidget()
        container_layout = QVBoxLayout(container_widget)
        container_layout.setContentsMargins(0, 0, 0, 0)
        
        # Close button
        self.close_button = QPushButton('X')
        self.close_button.setStyleSheet(
            """
            QPushButton {
                background-color: #FF0000; 
                color: white; 
                border: none; 
                font-size: 30px; 
                border-radius: 15px;
                padding: 10px;
                position: absolute;
                top: 10px;
                right: 10px;
            }
            QPushButton:hover {
                background-color: #CC0000;
            }
            """
        )
        self.close_button.setFixedSize(50, 50)
        self.close_button.clicked.connect(self.closeMenuOrder)
        
        # Add close button to the top-right corner
        container_layout.addWidget(self.close_button, alignment=Qt.AlignTop | Qt.AlignRight)

        # Main layout for the content
        content_layout = QHBoxLayout()

        # Fixed section layout
        self.section_buttons_layout = QVBoxLayout()
        self.section_buttons_layout.setAlignment(Qt.AlignTop)
        self.section_buttons_layout.setContentsMargins(0, 0, 0, 0)

        section_label = QLabel('SECTIONS')
        section_label.setAlignment(Qt.AlignCenter)
        section_label.setStyleSheet('font-size: 50px;')
        self.section_buttons_layout.addWidget(section_label)

        self.section_buttons_widget = QWidget()
        self.section_buttons_widget.setLayout(self.section_buttons_layout)

        # Articles layout
        self.grid_layout = QGridLayout()
        self.grid_layout.setSpacing(30)
        self.grid_layout.setContentsMargins(0, 0, 0, 0)

        self.articles_widget = QWidget()
        self.articles_widget.setLayout(self.grid_layout)

        # Fixed receipts layout
        self.receipt_layout = QVBoxLayout()
        self.receipt_layout.setAlignment(Qt.AlignTop)

        # Receipt Table
        self.receipt_table = QTableWidget()
        self.receipt_table.setColumnCount(3)
        self.receipt_table.setHorizontalHeaderLabels(['Name', 'Amount', 'Price'])
        self.receipt_table.horizontalHeader().setStyleSheet('font-size: 25px; color: white;')
        self.receipt_table.setStyleSheet(
            """
            QTableWidget {
                background-color: transparent;
                color: white;
                font-size: 25px;
                border: none;
            }
            QHeaderView::section {
                background-color: #4CAF50;
                padding: 5px;
                border: none;
            }
            """
        )
        self.receipt_table.setColumnWidth(0, 250)  # Adjust column width for "Name"
        self.receipt_table.setColumnWidth(1, 100)  # Adjust column width for "Amount"
        self.receipt_table.setColumnWidth(2, 150)  # Adjust column width for "Price"
        self.receipt_table.setEditTriggers(QAbstractItemView.NoEditTriggers)  # Make table non-editable
        self.receipt_table.setRowCount(0)

        self.receipt_layout.addWidget(self.receipt_table)

        # Separator line
        self.receipt_layout.addWidget(QLabel('_' * 30))

        # Total label
        self.total_label = QLabel('Total: 0.0 KM')
        self.total_label.setAlignment(Qt.AlignRight)
        self.total_label.setStyleSheet('font-size: 25px; color: white;')
        self.receipt_layout.addWidget(self.total_label)

        # Print button
        print_button = QPushButton('Print Receipt')
        print_button.setStyleSheet(
            """
            background-color: #4CAF50; 
            color: white; 
            border-radius: 10px; 
            padding: 10px; 
            font-size: 25px;
            """
        )
        print_button.clicked.connect(self.printReceipt)
        self.receipt_layout.addWidget(print_button, alignment=Qt.AlignCenter)

        self.receipt_widget = QWidget()
        self.receipt_widget.setLayout(self.receipt_layout)

        # Add layouts to content_layout with fixed proportions
        content_layout.addWidget(self.section_buttons_widget, 2)  # Fixed width for sections
        content_layout.addWidget(self.articles_widget, 5)         # Adjusted width for articles
        content_layout.addWidget(self.receipt_widget, 3)          # Fixed width for receipt

        # Add the content layout to the main layout, below the "ARTICLES" title
        container_layout.addLayout(content_layout)

        # Add the container widget to the main layout
        main_layout.addWidget(container_widget)

        # Set margins and spacing
        main_layout.setContentsMargins(10, 0, 10, 10)
        main_layout.setSpacing(30)

        self.setLayout(main_layout)
        self.resizeEvent = self.onResize
        self.show()

    def loadData(self):
        try:
            with open('articles.json', 'r') as f:
                self.data = json.load(f)
        except Exception as e:
            print(f"Error loading data: {e}")
            self.data = []
        
        self.sections = {}
        for item in self.data:
            section_name = item['section']
            if section_name not in self.sections:
                self.sections[section_name] = []
            self.sections[section_name].append(item)
        
        self.createSectionButtons()

    def createSectionButtons(self):
        for section_name in self.sections:
            button = QPushButton(section_name)
            button.setStyleSheet(
                """
                background-color: #4CAF50; 
                color: white; 
                border-radius: 15px; 
                padding: 15px; 
                font-size: 35px;
                """
            )
            button.setFixedSize(250, 120)
            button.clicked.connect(lambda _, s=section_name: self.showItems(s))
            self.section_buttons_layout.addWidget(button)

    def showItems(self, section_name):
        # Clear existing buttons
        for i in reversed(range(self.grid_layout.count())):
            item = self.grid_layout.itemAt(i)
            if item is not None:
                item.widget().deleteLater()

        items = sorted(self.sections[section_name], key=lambda x: x['name'])
        
        button_width = 200
        button_height = 150
        max_cols = 4  # Reduced to 4 columns
        
        num_buttons = len(items)
        num_rows = (num_buttons + max_cols - 1) // max_cols
        
        self.grid_layout.setRowStretch(num_rows, 1)
        
        for row in range(num_rows):
            for col in range(max_cols):
                index = row * max_cols + col
                if index < num_buttons:
                    item = items[index]
                    button = QPushButton(item['name'])
                    button.setStyleSheet(
                        """
                        background-color: #4CAF50; 
                        color: white; 
                        border-radius: 15px; 
                        padding: 15px; 
                        font-size: 35px;
                        """
                    )
                    button.setFixedSize(button_width, button_height)

                    button.clicked.connect(lambda _, i=item: self.addToReceipt(i))
                    self.grid_layout.addWidget(button, row, col)
                else:
                    empty_item = QWidget()
                    empty_item.setFixedSize(button_width, button_height)
                    self.grid_layout.addWidget(empty_item, row, col)

    def addToReceipt(self, item):
        try:
            # Find the price of the item from self.data
            item_price_str = next((article['price'] for article in self.data if article['name'] == item['name']), None)
            
            if item_price_str is None:
                print(f"Error: Price for item '{item['name']}' not found.")
                return
            
            # Convert the price from string to float
            item_price = float(item_price_str)
            
            # Check if item already exists in the table
            for row in range(self.receipt_table.rowCount()):
                name_item = self.receipt_table.item(row, 0)
                if name_item and name_item.text() == item['name']:
                    # Update existing row
                    amount_item = self.receipt_table.item(row, 1)
                    amount = int(amount_item.text()) + 1
                    amount_item.setText(str(amount))
                    
                    price_item = self.receipt_table.item(row, 2)
                    total_price = item_price * amount
                    price_item.setText(f"{total_price:.2f} KM")
                    
                    self.updateTotal()
                    return
            
            # Add new item
            row_position = self.receipt_table.rowCount()
            self.receipt_table.insertRow(row_position)
            self.receipt_table.setItem(row_position, 0, QTableWidgetItem(item['name']))
            self.receipt_table.setItem(row_position, 1, QTableWidgetItem('1'))
            self.receipt_table.setItem(row_position, 2, QTableWidgetItem(f"{item_price:.2f} KM"))

            self.receipt_items.append(item)
            self.updateTotal()
        except Exception as e:
            print(f"Error adding item to receipt: {e}")

    def updateTotal(self):
        try:
            total = 0.0
            for row in range(self.receipt_table.rowCount()):
                price_item = self.receipt_table.item(row, 2)
                if price_item:
                    price_text = price_item.text().replace(' KM', '')
                    total += float(price_text)
            self.total_label.setText(f"Total: {total:.2f} KM")
        except Exception as e:
            print(f"Error updating total: {e}")

    def printReceipt(self):
        try:
            # Clear the receipt table
            self.receipt_table.setRowCount(0)
            self.total_label.setText('Total: 0.0 KM')
            self.receipt_items.clear()

            print("Receipt has been cleared.")
        except Exception as e:
            print(f"Error clearing receipt: {e}")

    def loadReceiptData(self):
        try:
            receipt_file = f'receipt_{self.table_number}.json'
            with open(receipt_file, 'r') as f:
                receipt_data = json.load(f)
            
            self.receipt_table.setRowCount(0)  # Clear existing table data

            # Populate the receipt table with data from JSON
            for item in receipt_data:
                row_position = self.receipt_table.rowCount()
                self.receipt_table.insertRow(row_position)
                self.receipt_table.setItem(row_position, 0, QTableWidgetItem(item['name']))
                self.receipt_table.setItem(row_position, 1, QTableWidgetItem(str(item['amount'])))
                self.receipt_table.setItem(row_position, 2, QTableWidgetItem(f"{item['total_price']:.2f} KM"))

            # Update the total label
            self.updateTotal()
        
        except FileNotFoundError:
            print(f"No receipt data found for table {self.table_number}.")
        except Exception as e:
            print(f"Error loading receipt data: {e}")

    def updateTotal(self):
        try:
            total = 0.0
            for row in range(self.receipt_table.rowCount()):
                price_item = self.receipt_table.item(row, 2)
                if price_item:
                    price_text = price_item.text().replace(' KM', '')
                    total += float(price_text)
            self.total_label.setText(f"Total: {total:.2f} KM")
        except Exception as e:
            print(f"Error updating total: {e}")

    def onResize(self, event):
        if hasattr(self, 'current_section'):
            self.showItems(self.current_section)
        return QWidget.resizeEvent(self, event)

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        gradient = QLinearGradient(0, self.height(), 0, 0)
        gradient.setColorAt(0.0, QColor(0, 0, 0))
        gradient.setColorAt(1.0, QColor(50, 50, 50))

        painter.setBrush(QBrush(gradient))
        painter.drawRect(self.rect())

    def closeMenuOrder(self):
        # Collect receipt data including full item details
        receipt_data = []
        for row in range(self.receipt_table.rowCount()):
            item_name = self.receipt_table.item(row, 0).text()
            item_amount = int(self.receipt_table.item(row, 1).text())
            item_price = float(self.receipt_table.item(row, 2).text().replace(' KM', ''))
            
            # Find the full item details from self.data
            full_item_details = next((article for article in self.data if article['name'] == item_name), None)
            if full_item_details:
                # Add the amount and price to the item details
                full_item_details['amount'] = item_amount
                full_item_details['total_price'] = item_price  # Total price for this row
                receipt_data.append(full_item_details)
            else:
                print(f"Error: Details for item '{item_name}' not found in the article data.")

        # Save the receipt data to a JSON file
        try:
            with open(f'receipt_{self.table_number}.json', 'w') as f:
                json.dump(receipt_data, f, indent=4)
            print(f"Receipt for table {self.table_number} saved to 'receipt_{self.table_number}.json'.")
        except Exception as e:
            print(f"Error saving receipt data: {e}")

        # Emit the signal and close the menu
        if self.receipt_table.rowCount() > 0:
            self.receiptNotEmpty.emit(self.table_number, True)  # Emit the signal with the table number
        else:
            self.receiptNotEmpty.emit(self.table_number, False)

        self.close()

def main():
    import sys
    app = QApplication(sys.argv)
    login_page = LoginPage()
    login_page.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
