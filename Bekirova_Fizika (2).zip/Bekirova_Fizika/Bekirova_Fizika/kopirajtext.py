import os

# Define the path to the folder
folder_path = 'Federation of Bosnia and Herzegovina'
output_file = 'PrimjerSvihKomandi.txt'

# Open the output file in write mode
with open(output_file, 'w') as outfile:
    # Iterate over all files in the folder
    for filename in os.listdir(folder_path):
        # Check if the file is a text file
        if filename.endswith('.txt'):
            # Get the full path of the file
            file_path = os.path.join(folder_path, filename)
            # Read the content of the file
            with open(file_path, 'r') as infile:
                content = infile.read()
                # Write the file name and content to the output file
                outfile.write(f'--- {filename} ---\n')
                outfile.write(f'{content}\n\n')

print(f"All text files have been combined into {output_file}")
