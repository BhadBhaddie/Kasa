import os
import subprocess

# Define the command file path
command_file = "fiscal_machine_commands.txt"
batch_file = "Batt.bat"

# Initialize an empty string to store all commands
all_commands = ""

# Function to append a command to the string
def append_command(command):
    global all_commands
    all_commands += command + '\n'

# Function to write all commands to the file
def write_commands_to_file():
    with open(command_file, 'w') as file:
        file.write(all_commands)
    print(f"Commands written to {command_file}")

# Function to run the batch file
def run_batch_file():
    try:
        result = subprocess.run([batch_file], check=True, capture_output=True, text=True)
        print(f"Batch file output:\n{result.stdout}")
    except subprocess.CalledProcessError as e:
        print(f"Batch file failed with error:\n{e.stderr}")

# Function to open non-fiscal receipt
def open_non_fiscal_receipt():
    command = "38,1,______,_,__;"
    append_command(command)

# Function to print non-fiscal text
def print_non_fiscal_text(text):
    command = f"42,1,______,_,__[{text}];"
    append_command(command)

# Function to close non-fiscal receipt
def close_non_fiscal_receipt():
    command = "39,1,______,_,__;"
    append_command(command)

# Function to open fiscal receipt
def open_fiscal_receipt(iota, operator, password, till_number, receipt_number=None):
    command = f"48,1,______,_,__;"
    command += f"{iota};{operator};{password};{till_number}"
    if receipt_number:
        command += f";{receipt_number}"
    append_command(command)

# Function to sell an item
def sell_item(plu, quantity=1.000, percent=None):
    command = f"52,1,______,_,__;"
    command += f"{plu};{quantity}"
    if percent:
        command += f";{percent}"
    append_command(command)

# Function to subtotal
def subtotal():
    command = "51,1,______,_,__;"
    append_command(command)

# Function to make a payment
def payment(flag=0, amount=None):
    command = f"53,1,______,_,__;"
    if amount:
        command += f"{flag};{amount}"
    append_command(command)

# Function to enter client information (invoice)
def enter_client_information(ibk, line1, line2, line3, line4=None, line5=None, line6=None):
    command = f"55,1,______,_,__;"
    command += f"{ibk};{line1};{line2};{line3}"
    if line4:
        command += f";{line4}"
    if line5:
        command += f";{line5}"
    if line6:
        command += f";{line6}"
    append_command(command)

# Function to close fiscal receipt
def close_fiscal_receipt():
    command = "56,1,______,_,__;"
    append_command(command)

# Function to program items
def program_item(operation_type, tax_group=None, plu=None, price=None, name=None):
    command = f"107,1,______,_,__;"
    command += f"{operation_type}"
    if operation_type in [1, 2]:
        command += f";{tax_group};{plu};{price};{name}"
    elif operation_type == 3:
        command += f";{plu}" if plu else ";ALL"
    elif operation_type == 4:
        command += f";{plu};{price}"
    append_command(command)

# Function to clear the display
def clear_display():
    command = "33,1,______,_,__;"
    append_command(command)

# Function to show text on top row of the display
def show_text_top_row(text):
    command = f"47,1,______,_,__;{text};"
    append_command(command)

# Function to show text on bottom row of the display
def show_text_bottom_row(text):
    command = f"35,1,______,_,__;{text};"
    append_command(command)

# Function to show date and time
def show_date_time():
    command = "63,1,______,_,__;"
    append_command(command)

# Main function to execute commands interactively
def main():
    # List of functions to execute in order
    commands = [
        open_non_fiscal_receipt,
        lambda: print_non_fiscal_text("Non-fiscal text example"),
        close_non_fiscal_receipt,
        lambda: open_fiscal_receipt("1234567890123456", 1, "1234", 1),
        lambda: sell_item("11111111", 1.000),
        lambda: sell_item("22222222", 2.000, -10.00),
        subtotal,
        lambda: payment(0, 100),
        lambda: enter_client_information("1234567890123", "Line1", "Line2", "Line3"),
        close_fiscal_receipt,
        lambda: program_item(1, 1, "12345678", "100.00", "ItemName"),
        clear_display,
        lambda: show_text_top_row("Top row text"),
        lambda: show_text_bottom_row("Bottom row text"),
        show_date_time,
    ]

    for i, command in enumerate(commands):
        input("Press Enter to execute the next command or 'p' to pause: ")
        command()
        write_commands_to_file()
        run_batch_file()

        # Ask for feedback if 'p' was pressed
        if input("Enter 'p' to pause and give feedback or any other key to continue: ") == 'p':
            feedback = input("Please provide your feedback: ")
            print(f"Feedback: {feedback}")

if __name__ == "__main__":
    main()
